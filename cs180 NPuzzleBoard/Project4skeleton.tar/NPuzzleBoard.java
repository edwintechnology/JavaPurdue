/*
 * NPuzzleBoard.java
 *
 * Your task is to use arrays to complete this class.  You MUST fill in all the methods provided here.
 * You MUST use arrays.  You may add your own methods or other classes as necessary.
 */

public class NPuzzleBoard {
    // public state variables needed in NPuzzle
    public static int SCRAMBLE_MOVES = 50;  // the number of scrambles from the solution state to get a new game
    public static int DIMENSION = 4;        // the size of the puzzle

    public static final int BLANK = -1;     // the blank value - wherever the blank tile is, you should use this integer
                                            // value as a marker
    
    // put your additional class variables/constants here
    
    /**
     * Creates a new instance of NPuzzleBoard which is dimension x dimension in size.  You may want to add to this
     * method to have it create the necessary data structures and default anything else you find necessary.  Creating
     * a new NPuzzleBoard should also scramble the starting state of the N-Puzzle game.  You may implement the provided
     * scramble() method below and call that method to do this, or you may make your own design decisions if you wish.
     */
    public NPuzzleBoard(int dimension) {
        // allocate space for the board
        DIMENSION = dimension;

        // put your other constructor code here
        
    }
    
    /**
     * Scrambles the board from the solution state to a beginning puzzle state.  The number
     * of scrambling moves is defined by SCRAMBLE_MOVES.  A move is valid only if successful.
     * That is, if your blank is on the top, moving up is NOT considered a move.  Note that
     * implementing this method is optional.  You only need to implement it if you plan on using
     * it.
     */
    private void scramble() {
    }
    
    /**
     * Moves the blank on the board.  That is, if the direction of movement is up, the blank
     * moves up and a tile moves down.  This method returns true if the move was successful,
     * false if the blank cannot move in that particular direction.
     */
    public boolean move(int dir) {
        return false;
    }
    
    /**
     * Returns true if board is solved (all numbers are in place), false otherwise.
     */
    public boolean solved() {
        return false;
    }
    
    /**
     * Finds the location of num on the board and returns a value indicating the direction
     * from the blank to the num if the num tile is adjacent to the blank.  If the num tile
     * is not adjacent to the blank, return a value indicating so.
     */
    public int findDirectionFromBlank(int num) {
        return 0;
    }
    
    /**
     * Get the x coordinate of the blank tile.
     */
    public int getBlankX() {
        return 0;
    }
    
    /**
     * Get the y coordinate of the blank tile.
     */
    public int getBlankY() {
        return 0;
    }
    
    /**
     * Get the number on the tile at the coordinate (i,j).
     */
    public int getNumberAtCoordinate(int i, int j) {
        return 0;
    }

   /**
     * Sets this NPuzzleBoard to that of newBoard.  You may assume that the dimensions
     * of the two boards are the same.  You should NOT simply copy over reference addresses
     * even if your board array setup is the same as the parameter newBoard.  Instead, you
     * should make a deep copy of the board by copying over the tile numbers one by one
     * into your board representation.
     */
    public void setBoard(int[][] newBoard) {
    }
}
