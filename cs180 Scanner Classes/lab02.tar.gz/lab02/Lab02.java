/* 
 * CS 180 Lab02 Spring 2007
 *
 * Variables, Console I/O, BAC
 *
 * created by Jairav Desai 
 * edited by Zach Tatlock
 * and further so by Daniel Tang
 *
 */

//TODO: import the package that lets you use the Scanner class


public class Lab02
{
    //TODO: Create a constant double named BODYWATER_INDEX
    //      and set it to 240.4 (average for males and females)

    //TODO: Create a constant double named CORONA_INDEX
    //      and set it to 1016 (alcohol gained through one Corona)
    
    public static void main(String args[])
    {
        //TODO: Create a Scanner object named keyboard to get user input.
        //      Make sure to user System.in as a parameter to the Scanner
        //      constructor.
        
        //TODO: Create a double named bac for BAC
        
        //TODO: Create counter for total drinks consumed (integer)
         
        // Volume of body water calculated after input
        double waterVolume = 0.0; 
        
        System.out.println("Welcome to Brother's (est 1885).");
        System.out.print("\nWhat is your name? ");
        String name = keyboard.next();
        
        System.out.print("Hi " + name);
        System.out.print(", how much do you weigh? [whole number, lbs]: ");

        //TODO: Get the input of the user's weight as an int with 
        //      keyboard.nextInt() (store it somewhere)
        
        //TODO: Calculate body water volume and store it in 
        //      variable waterVolume.
        //
        //      The water volume is equal to the product of the
        //      user's weight and the body water index.
        
        System.out.print("\nYour total body water volume is ");
        Sytem.out.println(waterVolume +  " millilitres.");
        
        //TODO: Create a boolean variable to control the while loop.
        //      Initialize its value to true.
        
        while(/* the name of your boolean here */)
        {
            if(bac > 0.08)
            {
                //TODO: Let the user know that they cannot legally drive.
                //      Have a sober friend offer to drive them home.
            }
            
            if(bac > 0.35)
            {
                //TODO: Let the user know that they are dead.
                //      Exit the program using System.exit(0)
            }

            //TODO: Print the number of drinks the user has had.
            
            System.out.print("Would you like a Corona? ");
            String response = keyboard.next(); 
            
            // NOTE: Observe how String objects are compared
            if(response.equalsIgnoreCase("no"))
            {
                //TODO: Have the bouncer let the user know it is time to go.
                //      Change the value of the loop control variable to stop
                //      the loop.
            }
            else if(response.equalsIgnoreCase("yes"))
            {
                //TODO: Increment the counter for number of coronas consumed.
                //      Then calculate their BAC and print it out.
                //
                //      The user's BAC is equal to the product of the total
                //      number of drinks consumed and the Corona index, divided
                //      by the user's water volume.
            }
            
            //TODO: Print a blank line to help delimit iterations of the loop.
        }
    }
}
