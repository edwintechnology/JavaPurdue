// Declare that this object is in the Backend package.
package Backend;

public class Question
{
    // Each Question object will have two members: 
    //  question - a String representing a quiz question
    //  answer - a String representing the answer to question
	String question;
	String answer;	

    // This special function is called a constructor.
    // It creates Question objects. You'll work more with
    // objects in the weeks to come.
	public Question(String q, String a)
	{
		question = q;
		answer = a;
	}

	public String q()
	{
		return question;
	}

	public String a()
	{
		return answer;
	}

    // TODO 1
    //
    // Write the header for a public method named check 
    // that returns a boolean value and takes a String 
    // parameter named ans as a parameter.
    //
	{
        String answer = this.answer;

        // TODO 2
        //
        // Write an if statement that checks it the input
        // parameter ans is the same as the String answer.
		{
            // TODO 3
            //
            // Since ans matches answer, return a boolean
            // value that idicates true.
		}

        // TODO 4
        //
        // If code execution reaches this point, it means
        // that the return in the above if statement was
        // not executed. This, in turn, means that ans did
        // not match answer. So return a boolean value that
        // indicates false.
	}
}
