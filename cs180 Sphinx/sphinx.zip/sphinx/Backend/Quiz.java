// Declare that this object is in the Backend package.
package Backend;

// TODO 1
//
// Write the import statement that allows you to use the
// Scanner class. (Hint: This import statement has appeared
// at the top of every program you've seen that uses keyboard
// input.)

// We import the Categories package so we can use objects
// defined in files in ../Categories/*
import Categories.*;

public class Quiz
{
    // Each Quiz object will have one member:
    //  qs - a Question array representing the 
    //       questions in the Quiz
    //
    //  (Don't worry, you'll learn more about objects 
    //   and arrays later.)
	Question[] qs;

    // This special function is called a constructor.
    // It creates Quiz objects. You'll work more with
    // objects in the weeks to come.
	public Quiz(Category c, int nQs)
	{
        // This line creates space for a list of up
        // to nQs Question objects. You'll learn more
        // about arrays soon.
		qs = new Question[nQs];

        // TODO 2
        //
        // Write a for loop that uses an integer loop index
        // named i. Start with i at 0 and increment i after
        // each iteration as long as i is less than the integer
        // parameter nQs that was passed into the function.
		{
            // This sets the ith entry in the array qs to
            // the next question from the Category object
            // c. Although this line is cryptic now, it will
            // make perfect sense once you understand arrays
            // and objects (which is soon!).
			qs[i] = c.nextQuestion();
		}
	}


    // TODO 3
    //
    // Write the header for a public method named run
    // that does not return a value and takes no parameters.
    //
	{
        // TODO 4
        //
        // Declare a new Scanner object to read input from the
        // keyboard. Name this Scanner object in.

        // TODO 5
        //
        // Declare two integer variables, one named correct and
        // one named num. Set correct equal to 0 and num equal to 1.

		long start = System.currentTimeMillis();

        // TODO 6
        //
        // Write a for loop that uses an integer loop index
        // named i. Start with i at 0 and increment i after
        // each iteration as long as i is less than the integer
        // qs.length (which represents the number of Question
        // objects stored in the array qs).
		{
			System.out.print(num + ":\t" + qs[i].q());			
			String answer = in.nextLine();

            // TODO 7
            //
            // Replace the "code here" comment below
            // with a declaration for a boolean variable
            // named right.
            /* code here */ = qs[i].check(answer);

            // TODO 8
            //
            // Write an if statement to check whether or
            // not the the boolean variable named right
            // (that you created in TODO 7) is true.
			{
				System.out.println("\t\tCorrect.\n");
				correct++;
			}
            // TODO 9
            //
            // Write the keyword that will allow control to pass
            // to the below block if the above if statement
            // fails.
			{
				System.out.println("\t\tIncorrect. Should be " + qs[i].a() + ".\n");
			}

			num++;
		}

		long finish = System.currentTimeMillis();

		System.out.println();
		System.out.println("Correct:   " + correct);
		System.out.println("Incorrect: " + (qs.length - correct));
		System.out.println("Time:      " + ((finish - start)/1000) + " seconds\n\n");
	}
}
