package Categories;

import Backend.*;

public abstract class Category
{
	public abstract Question nextQuestion();
}
