package Categories;

import java.util.Random;
import Backend.*;

public class MultipleChoice extends Category
{
	Random rand;
	Category cat;
	int nOpt;

	public MultipleChoice(Category c, int n)
	{
		rand = new Random();
		cat = c;
		nOpt = n;
		if(nOpt < 2) nOpt = 2;
		if(nOpt > 8) nOpt = 8;
	}

	public Question nextQuestion()
	{
		String[] opts = {"A","B","C","D","E","F","G","H"};

		Question q = cat.nextQuestion();
		String prompt = q.q() + "\n";
		String a = q.a();
		String answer = "";

		int correctIndex = rand.nextInt(nOpt);

        // TODO 1
        //
        // Write a for loop that uses an integer loop index
        // named i. Start with i at 0 and increment i after
        // each iteration as long as i is less than the integer
        // variable nOpt.
		{
			if(i == correctIndex)
			{
				prompt += "\t\t" + opts[i] + ". " + a + "\n";
				answer = opts[i];
			}
			else
			{
				String opt = a;

                // TODO 2 
                //
                // Write a while loop that check whether the String
                // opt is the same as the String a.
				{
					Question oQ = cat.nextQuestion();
					opt = oQ.a();
				}

				prompt += "\t\t" + opts[i] + ". " + opt + "\n";
			}
		}

		prompt += "\t\tAnswer: ";
		
		return new Question(prompt,answer);
	}
}
