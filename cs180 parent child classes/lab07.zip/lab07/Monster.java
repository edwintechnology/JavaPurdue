public interface Monster
{
	void taunt();
}
